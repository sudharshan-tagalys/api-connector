export declare const APIConnector: {
    setQueryStringConfiguration: (config: any) => void;
    getPlatformVariable: (variableKey: any) => any;
    getPlatformVariables: () => any;
};
declare const setConfiguration: (config: any) => void;
export { setConfiguration };
