export declare const APIConnector: {
    setConfiguration: (config: any) => void;
    setQueryStringConfiguration: (config: any) => void;
    getRequestParamsFromQueryString: (queryString: any) => {};
};
