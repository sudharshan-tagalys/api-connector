export declare const APIConnector: {
    setConfiguration: (config: any) => void;
    test: () => void;
    setQueryStringConfiguration: (config: any) => void;
};
