export declare const APIConnector: {
    setConfiguration: (config: any) => void;
    queryString: {
        setConfiguration: (config: any) => void;
    };
};
