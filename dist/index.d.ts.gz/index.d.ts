import { SimilarProductsWidget } from "./similar-products-widget";
export declare const APIConnector: {
    setConfiguration: (config: any) => void;
    similarProductsWidget: typeof SimilarProductsWidget;
};
