export declare const APIConnector: {
    setConfiguration: (config: any) => void;
    setQueryStringConfiguration: (config: any) => void;
};
declare const setConfiguration: (config: any) => void;
export { setConfiguration };
