export declare const APIConnector: {
    setQueryStringConfiguration: (config: any) => void;
};
declare const setConfiguration: (config: any) => void;
export { setConfiguration };
