export declare const APIConnector: {
    SimilarProducts: {
        call: (requestOptions: any) => void;
    };
    SmartWidget: {
        call: (requestOptions: any) => void;
    };
    setConfiguration: (config: any) => void;
};
