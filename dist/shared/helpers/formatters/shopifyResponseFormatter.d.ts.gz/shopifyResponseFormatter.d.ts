import Formatter from './formatter';
declare class ShopifyResponseFormatter extends Formatter {
    formatDetail: (detail: any) => any;
}
export default ShopifyResponseFormatter;
