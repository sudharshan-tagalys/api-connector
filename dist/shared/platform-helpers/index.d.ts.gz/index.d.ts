import TagalysPlatformHelpers from 'platform-helpers';
export declare const setGlobalContextToPlatformHelpers: () => void;
export default TagalysPlatformHelpers;
