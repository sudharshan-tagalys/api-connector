declare const TagalysPlatformHelpers: any;
export declare const setGlobalContextToPlatformHelpers: () => void;
export default TagalysPlatformHelpers;
