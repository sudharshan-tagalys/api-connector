declare const _default: {
    getProducts: () => any;
    getTotalProductsCount: () => any;
    getRequestHelpers: () => {};
    getResponseHelpers: () => {
        getProducts: any;
        getTotalProductsCount: any;
    };
};
export default _default;
