declare const _default: {
    getProducts: () => any;
    getTotalProductsCount: () => any;
    getRequestHelpers: () => {};
    getResponseHelpers: () => {
        getProducts: any;
        hasNoSearchResults: any;
        getTotalProductsCount: any;
    };
    hasNoSearchResults: () => any;
};
export default _default;
