declare const _default: {
    setQuery: (query: any) => void;
    setQueryMode: (queryMode: any) => void;
    getRequestHelpers: () => {
        setQuery: any;
        setQueryMode: any;
    };
    getResponseHelpers: () => {};
};
export default _default;
