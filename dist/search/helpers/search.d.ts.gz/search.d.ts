declare const _default: {
    setQuery: (query: any) => void;
    getRequestHelpers: () => {
        setQuery: any;
    };
    getResponseHelpers: () => {};
};
export default _default;
