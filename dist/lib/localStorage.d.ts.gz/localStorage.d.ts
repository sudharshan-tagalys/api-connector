declare class LocalStorage {
    getItem(key: string): any;
    setValue(key: string, value: string): void;
}
declare const _default: LocalStorage;
export default _default;
