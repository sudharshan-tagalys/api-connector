import PlatformAnalyticsTracker from './platformAnalyticsTracker';
declare const _default: {
    tracker: (eventTypes: any) => PlatformAnalyticsTracker;
};
export default _default;
