import { WidgetRequestOptions } from "../shared/types";
interface SmartWidgetRequestOptions extends WidgetRequestOptions {
}
export { SmartWidgetRequestOptions };
