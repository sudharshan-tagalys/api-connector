import Widget from "../lib/widget";
declare class AddedToCartAlsoAddedToCart extends Widget {
    exporterName(): string;
    path(): string;
    plType(): string;
    formatResponse(response: any): any;
}
declare const _default: AddedToCartAlsoAddedToCart;
export default _default;
