import Widget from "../lib/widget";
declare class BoughtAlsoBought extends Widget {
    exporterName(): string;
    path(): string;
    plType(): string;
    formatResponse(response: any): any;
}
declare const _default: BoughtAlsoBought;
export default _default;
